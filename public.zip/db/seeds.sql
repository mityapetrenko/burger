INSERT INTO burgers (burger_name, devoured)  VALUES ("mcdouble", false);
INSERT INTO burgers (burger_name, devoured)  VALUES ("heart-attack", false);
INSERT INTO burgers (burger_name, devoured)  VALUES ("homemade burger with cheese", false);

